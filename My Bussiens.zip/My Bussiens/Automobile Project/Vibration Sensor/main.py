# import necessary liblaries
# ✔ and ✘ used in script

import os
import numpy as np
import matplotlib.pyplot as plt
from serial import Serial
from serial import SerialException
from datetime import datetime, timedelta
from scipy.interpolate import make_interp_spline as spline
from time import sleep

print('[✔] All liblaries are imported')

def get_status(value):
    if value > 10:
        return "The part in Bad Condition"
    elif value > 5:
        return "The part in Pending Condition"
    else:
        return "The part in Good Condition"

def cutOffCircuitNoice(data_array):
    filter1 = data_array <= 2
    filter2 = -2 <= data_array
    data_array[filter1 & filter2] = 0
    return data_array

def ConvertToNumpy(data_array):
    lengths = map(lambda list_: len(list_), data_array)
    minimum = min(lengths)

    for index, _ in enumerate(data_array):
        data_array[index] = data_array[index][:minimum]

    # set axis for the 0 axis
    numpy_array = np.array(data_array, dtype='float16')
    numpy_array = numpy_array.transpose()

    for index, array in enumerate(numpy_array):
        numpy_array[index] = array - np.mean(array)

    return numpy_array

def ExtractData(data_array, Identification):

    with open('report.txt', 'w') as report:
        report.write('AUTOMIBILE VIBRATION TEST REPORT\n')
        report.write('================================\n\n')

        report.write('Details of common variables set before testing\n')
        report.write('----------------------------------------------\n\n')

        report.write('Sampling Time       : {}\n'.format(SAMPLING_TIME))
        report.write('Communications Port : {}\n'.format(COM_PORT))
        report.write('Test Identification : {}\n\n'.format(Identification))

        report.write('Details of the probes\n')
        report.write('---------------------\n\n')

        for index, probe in enumerate(data_array):
            std_div = probe[probe != 0].std() #skip zeros and get others only
            probe_stat = get_status(std_div)

            report.write('Probe {}\n'.format(index + 1))
            report.write('\tStandard Deviation      : {}\n'.format(std_div))
            report.write('\tPart Computed Condition : {}\n\n'.format(probe_stat))

# draw plot
def DrawPlot(data_array):
    x_values = [i for i in range(data_array[0].size)]
    new_x_vals = np.linspace(0, data_array[0].size, data_array[0].size*100)
    ys = []

    for y_values in data_array:
        temp_instance = spline(x_values, y_values)
        new_y_vals = temp_instance(new_x_vals)
        ys.append(new_y_vals)

    fig, axs = plt.subplots(len(ys))
    fig.suptitle('Automobile Vibration Test Results', fontsize=14)
    #fig.xticks([])
    #fig.xlabel('Time Span', fontsize=10)
    #fig.ylabel('Sound Generated', fontsize=10)
    
    for index in range(len(ys)):
        axs[index].plot(new_x_vals, ys[index])

    fig.savefig(str(IDENTIFICATION) + '.png',  bbox_inches='tight', format='png', dpi=1200)


def startSerialCommunication():
    incrementor = '0'
    while True:
        try:
            COM_PORT = 'COM' + incrementor
            return Serial(COM_PORT, 9600), COM_PORT
        except SerialException:
            incrementor = str(int(incrementor) + 1)
            pass

arduino, COM_PORT = startSerialCommunication()
print(f'[✔] Communication started at {COM_PORT}')

print("Initializing arduino board")
sleep(2)
print("Checking for sound sensors")
sleep(4)
print("Done")
sleep(1)

SAMPLING_TIME = 10

# define calculated constants
time_delta = timedelta(0, SAMPLING_TIME)
data = []

# create the folder for the test
IDENTIFICATION = input('Enter the test Identification -> ').strip()
os.mkdir(IDENTIFICATION)
os.chdir(IDENTIFICATION)

# Show status to the user
print('[✔] Sampling started at {} for {} seconds'.format(COM_PORT, SAMPLING_TIME))
sleep(2)

# get current time
start_time = datetime.now()

# start sampling
while datetime.now() < start_time + time_delta:
    try:
        serial_data = arduino.readline()
        serial_data = serial_data[:-3].decode('utf-8').split(',')
        serial_data = list(map(int, serial_data))
        data.append(serial_data)
        
    except UnicodeDecodeError:
        pass
    except ValueError:
        pass

# close the communication
arduino.close()
# show status to the user
print('[✔] Sampling ended')

# convert data to numpy data and cut off all noices
data = ConvertToNumpy(data)
data = cutOffCircuitNoice(data)

# saving data to the file
np.savetxt('data.txt', data)

# get results of given data
ExtractData(data, IDENTIFICATION)


DrawPlot(data)
